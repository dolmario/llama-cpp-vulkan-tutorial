BACKEND CORRECTION / BACKEND-KORREKTUR: NVIDIA uses CUDA in this series.
This archive is the AMD/Vulkan path. For RTX3080Ti/RTX3090Ti use the CUDA kit from:
https://github.com/dolmario/llama-cpp-vulkan-tutorial/blob/main/CUDA/EN/START.md
https://github.com/dolmario/llama-cpp-vulkan-tutorial/blob/main/DOLMARIO-CUDA-EN.zip
No new NVIDIA inference or CUDA film has been completed yet. Original Git versions remain available.
