# AMD Strix Halo: llama.cpp mit Vulkan / with Vulkan

BACKEND-KORREKTUR07.10.2026: Dieses ZIP ist der AMD/Vulkan-Weg. Die zusätzlichen NVIDIA-Fassungen54–57 waren fälschlich für Vulkan vorbereitet. Für RTX3080Ti/3090Ti ist in Jörgs Reihe CUDA vorgesehen; diese bisherigen Filme sind gesperrt, die neue CUDA-Filmproduktion ist noch offen.

NVIDIA/CUDA instructions and downloads:
https://github.com/dolmario/llama-cpp-vulkan-tutorial/tree/main/CUDA
https://github.com/dolmario/llama-cpp-vulkan-tutorial/blob/main/DOLMARIO-CUDA-DE.zip
https://github.com/dolmario/llama-cpp-vulkan-tutorial/blob/main/DOLMARIO-CUDA-EN.zip

AMD: read START-DE.md or START-EN.md and PROFILE-STRIX-HALO.md. Existing AMD commands remain unchanged. A small optional GGUF example is documented separately. No model weights are bundled. Fresh installation/inference with this kit is still untested; historical device detection is separate evidence. No speed guarantee.

Alle ursprünglichen Dateien sind über die bisherigen Git-Versionen erhalten. Die jetzigen RTX-Profile verweisen ausdrücklich auf CUDA. Keine fremden Programme oder Server stoppen.
